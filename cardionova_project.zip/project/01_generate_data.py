"""
Step 1: Synthetic dataset generator
Scenario: "CardioNova" - a fictional branded anti-hypertensive launched by a pharma client.
The client's sales force calls on physicians (HCPs). Question: are calls allocated well?

Outputs (deliberately messy, like real client data):
  data/hcp_master_raw.csv        - one row per HCP
  data/monthly_activity_raw.csv  - one row per HCP-month (Oct-2024 .. Sep-2026)
"""
import numpy as np, pandas as pd, os

rng = np.random.default_rng(7)
os.makedirs("data", exist_ok=True)

N = 2500
MONTHS = pd.date_range("2024-10-01", periods=24, freq="MS")

specs = ["Cardiologist", "Internal Medicine", "General Practitioner", "Nephrologist", "Endocrinologist"]
spec_p = [0.18, 0.28, 0.36, 0.10, 0.08]
vol_mult = dict(zip(specs, [1.7, 1.2, 0.9, 0.8, 0.7]))
# max promotional lift and half-saturation (in 'effective calls') -> GPs most responsive, Cardiologists saturate early
resp_L = dict(zip(specs, [0.40, 0.60, 0.95, 0.50, 0.65]))
resp_k = dict(zip(specs, [5.0, 5.0, 4.5, 6.0, 5.0]))

regions = ["North", "South", "East", "West", "Central"]
reg_p = [0.22, 0.24, 0.18, 0.22, 0.14]
reg_exec = dict(zip(regions, [0.95, 1.05, 0.85, 1.10, 0.90]))   # rep execution vs plan
reg_share = dict(zip(regions, [1.00, 1.10, 0.95, 1.05, 0.90]))  # baseline brand affinity

hcp = pd.DataFrame({
    "hcp_id": [f"HCP{i:05d}" for i in range(1, N + 1)],
    "specialty": rng.choice(specs, N, p=spec_p),
    "region": rng.choice(regions, N, p=reg_p),
    "practice_type": rng.choice(["Hospital", "Private Clinic", "Group Practice"], N, p=[0.35, 0.40, 0.25]),
    "years_experience": np.clip(rng.normal(16, 8, N), 2, 42).round(),
    "kol_flag": rng.random(N) < 0.05,
    "email_opt_in": rng.random(N) < 0.60,
})
hcp["patient_volume"] = (rng.lognormal(4.2, 0.55, N) * hcp.specialty.map(vol_mult)).round()  # monthly hypertension pts

# Company's targeting tier: based on a NOISY potential score + a bias towards cardiologists (reps like them)
score = np.log(hcp.patient_volume) + np.where(hcp.specialty == "Cardiologist", 0.7, 0) + rng.normal(0, 0.45, N)
rank = score.rank(pct=True)
hcp["tier"] = np.select([rank > 0.80, rank > 0.50], ["A", "B"], "C")
planned = hcp.tier.map({"A": 4.0, "B": 2.5, "C": 1.0})

hcp["base_share"] = np.clip(rng.beta(4, 40, N) * hcp.region.map(reg_share), 0.02, 0.35)

rows = []
for i, h in hcp.iterrows():
    prev_e = 0.0
    for m_idx, m in enumerate(MONTHS):
        season = 1 + 0.08 * np.sin(2 * np.pi * (m.month - 1) / 12)
        growth = 1 + 0.004 * m_idx
        market_rx = max(0, rng.poisson(h.patient_volume * 0.8 * season * growth))
        calls = rng.poisson(planned[i] * reg_exec[h.region])
        emails = rng.poisson(1.5) if h.email_opt_in else 0
        samples = rng.poisson(calls * 0.8)
        event = int(rng.random() < (0.25 if h.kol_flag else 0.04))
        e = calls + 0.5 * prev_e + 0.3 * emails + 0.05 * samples + 1.5 * event
        prev_e = e
        lift = resp_L[h.specialty] * (1 - np.exp(-e / resp_k[h.specialty]))
        comp = 1.0
        if m_idx >= 14 and h.region in ("East", "Central"):
            comp = 0.86            # competitor launch Dec-2025
        elif m_idx >= 14:
            comp = 0.97
        share = h.base_share * (1 + lift) * comp
        brand_rx = rng.binomial(market_rx, min(share, 0.9))
        rows.append((h.hcp_id, m, market_rx, brand_rx, calls, emails, samples, event))

act = pd.DataFrame(rows, columns=["hcp_id", "month", "market_rx", "brand_rx", "calls", "emails", "samples", "events_attended"])
act["revenue_usd"] = act.brand_rx * 112.0

# ----------------- inject real-world mess -----------------
raw_h = hcp.drop(columns=["base_share"]).copy()      # base_share is the hidden truth, not shared
raw_h["specialty"] = raw_h.specialty.map(lambda s: rng.choice(
    {"Cardiologist": ["Cardiologist", "cardiology", "Cardio ", "CARDIOLOGIST"],
     "Internal Medicine": ["Internal Medicine", "internal medicine", "Int. Medicine", "IM"],
     "General Practitioner": ["General Practitioner", "GP", "general practitioner ", "Gen Practitioner"],
     "Nephrologist": ["Nephrologist", "nephrology", "Nephrologist "],
     "Endocrinologist": ["Endocrinologist", "endocrinology", "ENDOCRINOLOGIST"]}[s], p=None) if rng.random() < 0.25 else s)
raw_h["region"] = raw_h.region.map(lambda r: rng.choice([r.lower(), r.upper(), " " + r, r + " "]) if rng.random() < 0.15 else r)
raw_h.loc[rng.random(N) < 0.04, "patient_volume"] = np.nan
raw_h.loc[rng.random(N) < 0.06, "years_experience"] = np.nan
raw_h.loc[rng.random(N) < 0.02, "patient_volume"] = -1          # sentinel
raw_h.loc[rng.random(N) < 0.003, "patient_volume"] = 99999      # absurd outlier
raw_h = pd.concat([raw_h, raw_h.sample(40, random_state=1)])    # duplicates

a = act.copy()
fmt = rng.choice([0, 1, 2], len(a), p=[0.70, 0.20, 0.10])
a["month"] = [m.strftime(f) for m, f in zip(a.month, np.array(["%Y-%m-%d", "%d/%m/%Y", "%b-%y"])[fmt])]
a["hcp_id"] = a.hcp_id.where(rng.random(len(a)) > 0.01, a.hcp_id.str.lower())
a["calls"] = a.calls.astype(float)
a.loc[rng.random(len(a)) < 0.03, "calls"] = np.nan
a.loc[rng.random(len(a)) < 0.01, "samples"] = -3
a.loc[rng.random(len(a)) < 0.002, "brand_rx"] *= 10               # keying errors
a["revenue_usd"] = a.revenue_usd.astype(object)
mask = rng.random(len(a)) < 0.05
a.loc[mask, "revenue_usd"] = a.loc[mask, "revenue_usd"].map(lambda v: f"${v:,.0f}")
a = pd.concat([a, a.sample(int(0.015 * len(a)), random_state=2)])  # duplicates
a = a.sample(frac=1, random_state=3).reset_index(drop=True)

raw_h.to_csv("data/hcp_master_raw.csv", index=False)
a.to_csv("data/monthly_activity_raw.csv", index=False)
print("HCP master rows:", len(raw_h), "| Monthly activity rows:", len(a))
