"""
Step 3: Analysis, modelling & visualisation
Business question: CardioNova's sales force makes ~X calls/month on 2,500 physicians.
  (1) How is the brand performing and where is it losing ground?
  (2) Are calls going to the right doctors?
  (3) What is the best use of the SAME call budget, and what is it worth?
"""
import pandas as pd, numpy as np, json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

os.makedirs("charts", exist_ok=True); os.makedirs("outputs", exist_ok=True)
h = pd.read_csv("data/hcp_master_clean.csv")
a = pd.read_csv("data/monthly_activity_clean.csv", parse_dates=["month"])
d = a.merge(h, on="hcp_id")
PRICE = 112.0
COST = {"call": 65, "email": 2, "sample": 6, "event": 350}
LAUNCH = pd.Timestamp("2025-12-01")           # competitor launch (seen in the data; confirm with client in real life)
K = {}                                         # key numbers -> json for the report

# ---------------------------------------------------------------- style (palette from dataviz skill)
INK, INK2, MUTED, GRID, SURF = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#fcfcfb"
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]     # categorical slots 1-5, fixed order
SEQ = LinearSegmentedColormap.from_list("blue", ["#cde2fb", "#6da7ec", "#2a78d6", "#184f95", "#0d366b"])
plt.rcParams.update({
    "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
    "font.family": "DejaVu Sans", "font.size": 10, "text.color": INK, "axes.labelcolor": INK2,
    "xtick.color": MUTED, "ytick.color": MUTED, "axes.edgecolor": "#c3c2b7",
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "axes.titlesize": 12.5, "axes.titleweight": "bold",
    "axes.titlelocation": "left", "legend.frameon": False, "lines.linewidth": 2,
})
def headline(fig, title, sub=None):
    fig.text(0.01, 0.985, title, fontsize=14, fontweight="bold", va="top", color=INK)
    if sub: fig.text(0.01, 0.985 - 0.055, sub, fontsize=10, va="top", color=INK2)
def save(fig, name): fig.savefig(f"charts/{name}.png", dpi=170, bbox_inches="tight"); plt.close(fig)

REG = ["North", "South", "East", "West", "Central"]
SPEC = ["General Practitioner", "Internal Medicine", "Cardiologist", "Nephrologist", "Endocrinologist"]

# ================================================================ 1. Headline KPIs
tot = d.groupby("month").agg(brand=("brand_rx", "sum"), mkt=("market_rx", "sum"), rev=("revenue_usd", "sum"),
                             calls=("calls", "sum"), emails=("emails", "sum"), samples=("samples", "sum"),
                             events=("events_attended", "sum"))
tot["share"] = tot.brand / tot.mkt
last12, prev12 = tot.iloc[12:], tot.iloc[:12]
K["revenue_L12M_usd"] = float(last12.rev.sum()); K["revenue_P12M_usd"] = float(prev12.rev.sum())
K["revenue_yoy_pct"] = float(last12.rev.sum() / prev12.rev.sum() - 1) * 100
K["market_rx_yoy_pct"] = float(last12.mkt.sum() / prev12.mkt.sum() - 1) * 100
K["share_L12M_pct"] = float(last12.brand.sum() / last12.mkt.sum()) * 100
K["share_P12M_pct"] = float(prev12.brand.sum() / prev12.mkt.sum()) * 100
K["calls_per_month_avg"] = float(tot.calls.mean())
spend = tot.calls * COST["call"] + tot.emails * COST["email"] + tot.samples * COST["sample"] + tot.events * COST["event"]
K["promo_spend_L12M_usd"] = float(spend.iloc[12:].sum()); K["promo_spend_P12M_usd"] = float(spend.iloc[:12].sum())
K["roi_L12M"] = float(last12.rev.sum() / spend.iloc[12:].sum())
K["roi_P12M"] = float(prev12.rev.sum() / spend.iloc[:12].sum())
K["share_pre_launch_pct"] = float(tot.loc[tot.index < LAUNCH, "brand"].sum() / tot.loc[tot.index < LAUNCH, "mkt"].sum()) * 100
K["share_post_launch_pct"] = float(tot.loc[tot.index >= LAUNCH, "brand"].sum() / tot.loc[tot.index >= LAUNCH, "mkt"].sum()) * 100

# ---- Fig 1: revenue + share by region
rs = d.groupby(["month", "region"]).agg(b=("brand_rx", "sum"), m=("market_rx", "sum")).reset_index()
rs["share"] = rs.b / rs.m * 100
fig, ax = plt.subplots(1, 2, figsize=(13, 4.6), gridspec_kw={"width_ratios": [1, 1.25]})
ax[0].plot(tot.index, tot.rev / 1e6, color=C[0]); ax[0].set_ylim(0)
ax[0].set_title("Monthly brand revenue ($M)"); ax[0].set_ylabel("$M")
for x in ax:
    x.axvline(LAUNCH, color=MUTED, ls=(0, (4, 3)), lw=1)
ax[0].text(LAUNCH, ax[0].get_ylim()[1] * 0.97, " Competitor\n launch", fontsize=8.5, color=INK2, va="top")
for i, r in enumerate(REG):
    s = rs[rs.region == r]; ax[1].plot(s.month, s.share, color=C[i], label=r)
    ax[1].text(s.month.iloc[-1] + pd.Timedelta(days=12), s.share.iloc[-1], r, color=INK2, fontsize=9, va="center")
ax[1].set_title("Brand share of hypertension Rx, by region (%)"); ax[1].set_xlim(right=tot.index[-1] + pd.Timedelta(days=95))
ax[1].legend(ncol=5, loc="upper center", bbox_to_anchor=(0.5, -0.12), fontsize=9)
for x in ax: x.tick_params(axis="x", rotation=0); x.xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%b-%y"))
fig.autofmt_xdate(rotation=0, ha="center")
headline(fig, "Revenue is flat while the market grows ~5%: share is slipping since the competitor launch")
fig.tight_layout(rect=(0, 0, 1, 0.93)); save(fig, "fig1_trend")

# ================================================================ 2. Competitor impact
pre = d[d.month < LAUNCH].groupby("region").apply(lambda g: g.brand_rx.sum() / g.market_rx.sum() * 100)
post = d[d.month >= LAUNCH].groupby("region").apply(lambda g: g.brand_rx.sum() / g.market_rx.sum() * 100)
imp = pd.DataFrame({"pre": pre, "post": post}).loc[REG]; imp["chg_pts"] = imp.post - imp.pre; imp["chg_pct"] = imp.chg_pts / imp.pre * 100
K["competitor_impact"] = imp.round(2).to_dict("index")
# revenue at risk: lost Rx x price, annualised
post_months = d[d.month >= LAUNCH].month.nunique()
lost = ((imp.pre - imp.post) / 100 * d[d.month >= LAUNCH].groupby("region").market_rx.sum().loc[REG] * PRICE)
K["share_loss_revenue_usd_annualised"] = float(lost.sum() / post_months * 12)
K["share_loss_by_region_annualised"] = (lost / post_months * 12).round(0).to_dict()

fig, ax = plt.subplots(figsize=(8.5, 4.4)); x = np.arange(5); w = 0.36
b1 = ax.bar(x - w / 2, imp.pre, w, color=C[0], label="Before launch (Oct-24 to Nov-25)")
b2 = ax.bar(x + w / 2, imp.post, w, color=C[1], label="After launch (Dec-25 to Sep-26)")
for bars in (b1, b2):
    for r in bars: ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 0.15, f"{r.get_height():.1f}", ha="center", fontsize=8.5, color=INK2)
ax.set_xticks(x); ax.set_xticklabels([f"{r}\n{imp.chg_pct[r]:+.0f}%" for r in REG], fontsize=10); ax.set_ylabel("Brand share (%)"); ax.grid(axis="x", visible=False)
ax.set_ylim(0, 17); ax.legend(loc="upper center", ncol=2, fontsize=8.5, bbox_to_anchor=(0.5, 1.0))
headline(fig, "East and Central lost ~13% of their share after the launch; other regions lost ~2%")
fig.tight_layout(rect=(0, 0, 1, 0.93)); save(fig, "fig2_competitor_impact")

# ================================================================ 3. Share heatmap
hm = d[d.month >= d.month.max() - pd.DateOffset(months=11)]
hm = hm.groupby(["specialty", "region"]).apply(lambda g: g.brand_rx.sum() / g.market_rx.sum() * 100).unstack().loc[SPEC, REG]
fig, ax = plt.subplots(figsize=(8, 4.2))
im = ax.imshow(hm.values, cmap=SEQ, aspect="auto")
for i in range(5):
    for j in range(5):
        v = hm.values[i, j]; ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=10, color="white" if v > hm.values.mean() else INK)
ax.set_xticks(range(5)); ax.set_xticklabels(REG); ax.set_yticks(range(5)); ax.set_yticklabels(SPEC); ax.grid(False)
for s in ax.spines.values(): s.set_visible(False)
cb = fig.colorbar(im, ax=ax, fraction=0.04); cb.set_label("Share (%)"); cb.outline.set_visible(False)
headline(fig, "Share by specialty x region, last 12 months (%)")
fig.tight_layout(rect=(0, 0, 1, 0.93)); save(fig, "fig3_share_heatmap")
K["share_by_specialty_L12M"] = d[d.month >= d.month.max() - pd.DateOffset(months=11)].groupby("specialty").apply(
    lambda g: g.brand_rx.sum() / g.market_rx.sum() * 100).round(2).to_dict()

# ================================================================ 4. HCP-level table & targeting diagnosis
P = d[d.month < LAUNCH]       # pre-launch window: clean read of promotion response
L12 = d[d.month >= d.month.max() - pd.DateOffset(months=11)]
hc = L12.groupby("hcp_id").agg(brand=("brand_rx", "sum"), mkt=("market_rx", "sum"), calls=("calls", "mean"),
                               emails=("emails", "mean"), samples=("samples", "mean")).reset_index()
hc = hc.merge(h, on="hcp_id"); hc["potential"] = hc.mkt / 12          # monthly category Rx = true potential
hc["share"] = hc.brand / hc.mkt
K["n_hcp"] = len(hc)
K["calls_total_per_month_L12M"] = float(hc.calls.sum())

# fig 4: where do calls go vs where is the potential?
by_spec = hc.groupby("specialty").agg(calls=("calls", "sum"), pot=("potential", "sum"), n=("hcp_id", "count")).loc[SPEC]
by_spec["call_share"] = by_spec.calls / by_spec.calls.sum() * 100; by_spec["pot_share"] = by_spec.pot / by_spec.pot.sum() * 100
K["call_vs_potential_share_by_specialty"] = by_spec[["call_share", "pot_share"]].round(1).to_dict("index")
hc["pot_decile"] = pd.qcut(hc.potential, 10, labels=False) + 1
dec = hc.groupby("pot_decile").agg(calls=("calls", "mean"), pot=("potential", "sum"))
dec["pot_share"] = dec.pot / dec.pot.sum() * 100
K["top3_decile_potential_share_pct"] = float(dec.pot_share.iloc[-3:].sum())
K["top3_decile_calls_share_pct"] = float(hc[hc.pot_decile >= 8].calls.sum() / hc.calls.sum() * 100)
K["top_decile_potential_share_pct"] = float(dec.pot_share.iloc[-1]); K["top_decile_calls_share_pct"] = float(hc[hc.pot_decile == 10].calls.sum() / hc.calls.sum() * 100)
K["corr_calls_vs_potential"] = float(np.corrcoef(hc.calls, hc.potential)[0, 1])

fig, ax = plt.subplots(1, 2, figsize=(13, 4.6))
w = 0.38; dc = hc.groupby("pot_decile").calls.sum() / hc.calls.sum() * 100
ax[0].bar(dec.index - w / 2, dec.pot_share, w, color=C[0], label="Share of market potential")
ax[0].bar(dec.index + w / 2, dc, w, color=C[1], label="Share of sales calls")
ax[0].set_xticks(dec.index); ax[0].set_xlabel("HCP potential decile (10 = highest-volume doctors)"); ax[0].set_ylabel("% of total")
ax[0].set_title("Potential vs calls, by decile (%)"); ax[0].grid(axis="x", visible=False); ax[0].legend(fontsize=8.5, loc="upper left")
ax[1].bar(dec.index, dec.calls, color=C[0], width=0.7)
for i, v in zip(dec.index, dec.calls): ax[1].text(i, v + 0.05, f"{v:.1f}", ha="center", fontsize=8.5, color=INK2)
ax[1].set_xticks(dec.index); ax[1].set_xlabel("HCP potential decile (10 = highest-volume doctors)"); ax[1].set_ylabel("Avg calls / month")
ax[1].set_title("Avg calls per doctor"); ax[1].grid(axis="x", visible=False)
headline(fig, f"The top decile of doctors holds {dec.pot_share.iloc[-1]:.0f}% of potential but receives only {dc.iloc[-1]:.0f}% of calls")
fig.tight_layout(rect=(0, 0, 1, 0.93)); save(fig, "fig4_misallocation")

# 2x2: potential x call intensity
hi_pot = hc.potential >= hc.potential.quantile(0.60); hi_call = hc.calls >= 2.5
hc["segment"] = np.select([hi_pot & hi_call, hi_pot & ~hi_call, ~hi_pot & hi_call], ["Protect", "Under-served", "Over-served"], "Maintain")
seg = hc.groupby("segment").agg(hcps=("hcp_id", "count"), calls=("calls", "sum"), pot=("potential", "sum"), brand=("brand", "sum"), mkt=("mkt", "sum"))
seg["call_share"] = seg.calls / seg.calls.sum() * 100; seg["pot_share"] = seg.pot / seg.pot.sum() * 100; seg["share"] = seg.brand / seg.mkt * 100
K["segments"] = seg.round(2).to_dict("index")

fig, ax = plt.subplots(figsize=(8.5, 5.4))
cols = {"Under-served": C[1], "Over-served": C[0]}
hc["seg_plot"] = hc.segment.where(hc.segment.isin(["Under-served", "Over-served"]), "Other (Protect + Maintain)")
for s_ in ["Other (Protect + Maintain)", "Under-served", "Over-served"]:
    g = hc[hc.seg_plot == s_]
    ax.scatter(g.calls + np.random.default_rng(1).normal(0, 0.05, len(g)), g.potential, s=14, alpha=0.7,
               color=cols.get(s_, "#c3c2b7"), edgecolor=SURF, linewidth=0.4, label=f"{s_} ({len(g)})")
ax.axvline(2.5, color=MUTED, lw=1, ls=(0, (4, 3))); ax.axhline(hc.potential.quantile(0.60), color=MUTED, lw=1, ls=(0, (4, 3)))
ax.set_yscale("log"); ax.set_xlabel("Avg sales calls / month (last 12 months)"); ax.set_ylabel("Market potential: category Rx / month (log)")
ax.legend(fontsize=8.5, loc="lower right", markerscale=1.5)
headline(fig, "Under-served doctors (orange) are high-potential HCPs getting < 2.5 calls a month")
fig.tight_layout(rect=(0, 0, 1, 0.94)); save(fig, "fig5_segments")

# ================================================================ 5. Promotion response (pre-launch window only)
pc = P.groupby("hcp_id").agg(brand=("brand_rx", "sum"), mkt=("market_rx", "sum"), calls=("calls", "mean")).reset_index().merge(h, on="hcp_id")
pc["share"] = pc.brand / pc.mkt; pc["lc"] = np.log1p(pc.calls)
theta, base = {}, {}
fig, ax = plt.subplots(figsize=(9, 5))
grid = np.linspace(0.5, 6, 60)
for i, s_ in enumerate(SPEC):
    g = pc[pc.specialty == s_]
    X = np.column_stack([np.ones(len(g)), g.lc] + [(g.region == r).astype(float) for r in REG[1:]])
    beta = np.linalg.lstsq(X, g.share, rcond=None)[0]
    icpt = float(g.share.mean() - beta[1] * g.lc.mean())            # avg share at zero calls (region-adjusted)
    theta[s_] = float(beta[1] / icpt); base[s_] = icpt
    ax.plot(grid, (icpt + beta[1] * np.log1p(grid)) * 100, color=C[i])
    ax.text(6.05, (icpt + beta[1] * np.log1p(6)) * 100, s_, fontsize=8.5, color=INK2, va="center")
    bins = pd.qcut(g.calls, 6, duplicates="drop")
    bm = g.groupby(bins, observed=True).agg(c=("calls", "mean"), s=("share", "mean"))
    ax.scatter(bm.c, bm.s * 100, s=28, color=C[i], edgecolor=SURF, linewidth=1.2, zorder=3)
ax.set_xlim(0.4, 8.2); ax.set_xlabel("Avg calls / month"); ax.set_ylabel("Brand share (%), pre-launch")
headline(fig, "Every call lifts share, but returns diminish - GPs respond most per call, cardiologists least")
fig.tight_layout(rect=(0, 0, 1, 0.94)); save(fig, "fig6_response_curves")
K["response_theta"] = {k: round(v, 3) for k, v in theta.items()}
K["share_lift_going_from_1_to_4_calls_pct"] = {s_: round(((1 + theta[s_] * np.log(5)) / (1 + theta[s_] * np.log(2)) - 1) * 100, 1) for s_ in SPEC}

# ================================================================ 6. Channel effectiveness (within-HCP regression)
dd = d.sort_values(["hcp_id", "month"]).copy()
dd["share"] = dd.brand_rx / dd.market_rx.clip(lower=1)
dd["calls_l1"] = dd.groupby("hcp_id").calls.shift(1)
dd["post"] = (dd.month >= LAUNCH).astype(float)
dd = dd.dropna(subset=["calls_l1"])
cols_ = ["calls", "calls_l1", "emails", "samples", "events_attended", "post"]
Z = dd[["share"] + cols_].copy()
Z = Z - Z.groupby(dd.hcp_id).transform("mean")                 # HCP fixed effects
beta = np.linalg.lstsq(Z[cols_].values, Z.share.values, rcond=None)[0]
coef = dict(zip(cols_, beta))
avg_mkt = d.market_rx.mean()
ch = pd.DataFrame({
    "channel": ["Sales call", "Email", "Sample drop", "Event attendance"],
    "rx_per_unit": [(coef["calls"] + coef["calls_l1"]) * avg_mkt, coef["emails"] * avg_mkt, coef["samples"] * avg_mkt, coef["events_attended"] * avg_mkt],
    "cost": [COST["call"], COST["email"], COST["sample"], COST["event"]]})
ch["rx_per_1k_usd"] = ch.rx_per_unit / ch.cost * 1000; ch["revenue_per_usd"] = ch.rx_per_unit * PRICE / ch.cost
K["channel_effectiveness"] = ch.round(3).set_index("channel").to_dict("index")

fig, ax = plt.subplots(1, 2, figsize=(12, 4.2))
ax[0].barh(ch.channel[::-1], ch.rx_per_unit[::-1], color=C[0], height=0.55)
for i, v in enumerate(ch.rx_per_unit[::-1]): ax[0].text(v + 0.004, i, f"{v:.2f}", va="center", fontsize=9, color=INK2)
ax[0].set_title("Incremental Rx per touchpoint"); ax[0].grid(axis="y", visible=False)
ax[1].barh(ch.channel[::-1], ch.revenue_per_usd[::-1], color=C[1], height=0.55)
for i, v in enumerate(ch.revenue_per_usd[::-1]): ax[1].text(v + 0.05, i, f"${v:.1f}", va="center", fontsize=9, color=INK2)
ax[1].set_title("Revenue returned per $1 spent"); ax[1].grid(axis="y", visible=False)
headline(fig, "Emails return ~$4 per $1 spent; calls ~$0.7; samples and events under $0.2")
fig.tight_layout(rect=(0, 0, 1, 0.92)); save(fig, "fig7_channels")

# ================================================================ 7. Optimisation: same call budget, smarter allocation
hc["s_hat"] = hc.share
grp = hc.groupby(["specialty", "region"]).share.transform("mean")
hc["theta"] = hc.specialty.map(theta)
hc["base_i"] = (0.5 * hc.share + 0.5 * grp) / (1 + hc.theta * np.log1p(hc.calls))   # shrunk, implied zero-call share
hc["A"] = hc.potential * hc.base_i * hc.theta                                         # Rx gain scale per ln(1+c)
BUDGET = hc.calls.sum(); CMIN, CMAX = 1.0, 6.0
kol = hc.kol_flag.values                               # KOLs: relationship accounts, call levels held fixed
LO = np.where(kol, hc.calls.values, CMIN); HI = np.where(kol, hc.calls.values, CMAX)
def alloc(mu): return np.clip(mu * hc.A.values - 1, LO, HI)
lo, hi = 1e-6, 1e3
for _ in range(80):
    mid = (lo + hi) / 2
    lo, hi = (mid, hi) if alloc(mid).sum() < BUDGET else (lo, mid)
hc["calls_opt"] = alloc((lo + hi) / 2)
def rx_at(c): return hc.potential.values * 12 * hc.base_i.values * (1 + hc.theta.values * np.log1p(c))
hc["rx_now_model"] = rx_at(hc.calls.values)
scen = {}
for name, lam in [("Full re-allocation", 1.0), ("Phased (30% of the shift)", 0.3)]:
    c_new = hc.calls + lam * (hc.calls_opt - hc.calls)
    gain = (rx_at(c_new.values) - hc.rx_now_model.values).sum()
    scen[name] = {"calls_moved_per_month": float(np.abs(c_new - hc.calls).sum() / 2), "calls_moved_pct": float(np.abs(c_new - hc.calls).sum() / 2 / BUDGET * 100),
                  "incremental_rx_per_year": float(gain), "incremental_revenue_usd_per_year": float(gain * PRICE),
                  "pct_of_L12M_brand_rx": float(gain / hc.brand.sum() * 100)}
    if lam == 1.0: hc["calls_new"] = c_new; hc["gain_rx_year"] = rx_at(c_new.values) - hc.rx_now_model.values
K["scenarios"] = scen; K["call_budget_per_month"] = float(BUDGET)
K["model_vs_actual_L12M_rx"] = [float(hc.rx_now_model.sum()), float(hc.brand.sum())]

ch_spec = hc.groupby("specialty").agg(now=("calls", "sum"), opt=("calls_opt", "sum"), gain=("gain_rx_year", "sum")).loc[SPEC]
ch_seg = hc.groupby("segment").agg(now=("calls", "sum"), opt=("calls_opt", "sum"), gain=("gain_rx_year", "sum"))
K["calls_now_vs_opt_by_specialty"] = ch_spec.round(1).to_dict("index"); K["calls_now_vs_opt_by_segment"] = ch_seg.round(1).to_dict("index")
K["underserved_n"] = int((hc.segment == "Under-served").sum()); K["overserved_n"] = int((hc.segment == "Over-served").sum())

fig, ax = plt.subplots(1, 2, figsize=(13, 4.6))
order = ["Under-served", "Protect", "Maintain", "Over-served"]; x = np.arange(4)
ax[0].bar(x - w / 2, ch_seg.loc[order].now, w, color=C[0], label="Current plan"); ax[0].bar(x + w / 2, ch_seg.loc[order].opt, w, color=C[1], label="Recommended")
for i, o in enumerate(order):
    ax[0].text(i - w / 2, ch_seg.now[o] + 25, f"{ch_seg.now[o]:,.0f}", ha="center", fontsize=8.5, color=INK2)
    ax[0].text(i + w / 2, ch_seg.opt[o] + 25, f"{ch_seg.opt[o]:,.0f}", ha="center", fontsize=8.5, color=INK2)
ax[0].set_xticks(x); ax[0].set_xticklabels(order); ax[0].set_title("Calls per month by HCP segment"); ax[0].grid(axis="x", visible=False); ax[0].legend(fontsize=8.5)
sc = pd.Series({k: v["incremental_rx_per_year"] for k, v in scen.items()})
ax[1].bar(range(2), sc.values, color=C[0], width=0.5)
for i, v in enumerate(sc.values): ax[1].text(i, v + 250, f"+{v:,.0f} Rx\n(~${v * PRICE / 1e6:.2f}M)", ha="center", fontsize=9.5, color=INK)
ax[1].set_xticks(range(2)); ax[1].set_xticklabels(sc.index); ax[1].set_ylim(0, sc.max() * 1.25); ax[1].grid(axis="x", visible=False)
ax[1].set_title("Modelled incremental Rx per year, same call budget")
headline(fig, "Moving calls from over-served to under-served doctors adds Rx at zero extra cost")
fig.tight_layout(rect=(0, 0, 1, 0.93)); save(fig, "fig8_reallocation")

# ---- marginal value of one more call at the current allocation (per HCP, per month)
hc["marg_rx_per_call"] = hc.potential * hc.base_i * hc.theta / (1 + hc.calls)
hc["marg_rev_per_call"] = hc.marg_rx_per_call * PRICE
below = hc.marg_rev_per_call < COST["call"]
K["marginal_rev_per_call_median"] = float(hc.marg_rev_per_call.median())
K["pct_hcps_below_breakeven"] = float(below.mean() * 100)
K["calls_to_below_breakeven_hcps"] = float(hc.calls[below].sum()); K["pct_calls_below_breakeven"] = float(hc.calls[below].sum() / hc.calls.sum() * 100)
K["below_breakeven_by_specialty"] = hc[below].groupby("specialty").calls.sum().round(0).to_dict()
K["below_breakeven_by_segment"] = hc[below].groupby("segment").calls.sum().round(0).to_dict()
K["avg_marg_rev_by_specialty"] = hc.groupby("specialty").marg_rev_per_call.median().round(1).to_dict()
fig, ax = plt.subplots(figsize=(9, 4.6))
bins_ = np.linspace(0, min(hc.marg_rev_per_call.quantile(0.99), 400), 45)
ax.hist(hc.marg_rev_per_call.clip(upper=bins_[-1]), bins=bins_, color=C[0], edgecolor=SURF, linewidth=0.6)
ax.axvline(COST["call"], color=C[1], lw=2)
ax.text(COST["call"] + 4, ax.get_ylim()[1] * 0.92, f"Cost of a call (${COST['call']})\n{below.mean() * 100:.0f}% of doctors sit below it", color=INK, fontsize=9.5, va="top")
ax.set_xlabel("Revenue from one extra call, per doctor per month ($; last bar = $250+)"); ax.set_ylabel("Number of HCPs"); ax.grid(axis="x", visible=False)
headline(fig, "About half of doctors return less than a call costs, while a minority return several times more")
fig.tight_layout(rect=(0, 0, 1, 0.93)); save(fig, "fig9_marginal_call_value")

# ================================================================ 8. Early-warning watchlist
rec = d[d.month >= d.month.max() - pd.DateOffset(months=5)].groupby("hcp_id").agg(b=("brand_rx", "sum"), m=("market_rx", "sum"))
old = d[(d.month >= d.month.max() - pd.DateOffset(months=17)) & (d.month < d.month.max() - pd.DateOffset(months=5))].groupby("hcp_id").agg(b0=("brand_rx", "sum"), m0=("market_rx", "sum"))
wl = rec.join(old); wl["share_recent"] = wl.b / wl.m; wl["share_prior"] = wl.b0 / wl.m0; wl["rx_drop_pct"] = (wl.share_recent / wl.share_prior - 1) * 100
wl = wl.join(hc.set_index("hcp_id")[["specialty", "region", "tier", "potential", "calls", "segment"]])
wl["rx_lost_annualised"] = (wl.share_prior - wl.share_recent) * wl.potential * 12
watch = wl[(wl.rx_drop_pct < -25) & (wl.potential >= hc.potential.quantile(0.6)) & (wl.b0 >= 20)].sort_values("rx_lost_annualised", ascending=False)
K["watchlist_n"] = len(watch); K["watchlist_rx_lost_annualised"] = float(watch.rx_lost_annualised.sum())
K["watchlist_by_region"] = watch.region.value_counts().to_dict()
K["watchlist_avg_calls"] = float(watch.calls.mean()); K["all_avg_calls"] = float(hc.calls.mean())
watch.round(3).to_csv("outputs/watchlist_high_value_declining_hcps.csv")

# ================================================================ save tables
hc[["hcp_id", "specialty", "region", "practice_type", "tier", "kol_flag", "potential", "share", "calls", "segment", "calls_opt", "calls_new", "gain_rx_year"]].round(3)\
  .rename(columns={"calls": "calls_current_per_month", "calls_opt": "calls_optimal_per_month", "calls_new": "calls_recommended_per_month", "gain_rx_year": "modelled_rx_gain_per_year"})\
  .to_csv("outputs/hcp_call_plan.csv", index=False)
ch.round(3).to_csv("outputs/channel_effectiveness.csv", index=False)
tot.round(4).to_csv("outputs/monthly_kpis.csv")
json.dump(K, open("outputs/key_metrics.json", "w"), indent=2, default=float)
print(json.dumps(K, indent=1, default=float))
