"""
Step 2: Data cleaning & validation
Reads raw CSVs, fixes quality issues, writes clean CSVs + a cleaning log (every fix is counted).
"""
import pandas as pd, numpy as np, json, os

os.makedirs("data", exist_ok=True)
log = {}
PRICE = 112.0   # net revenue per Rx (client-provided constant; validated against the revenue column below)

# ------------------------------------------------------------------ HCP master
h = pd.read_csv("data/hcp_master_raw.csv")
log["hcp_rows_raw"] = len(h)

# 1. duplicates
n = len(h); h = h.drop_duplicates(subset="hcp_id", keep="first")
log["hcp_duplicates_removed"] = n - len(h)

# 2. specialty label harmonisation
spec_map = {
    "cardiologist": "Cardiologist", "cardiology": "Cardiologist", "cardio": "Cardiologist",
    "internal medicine": "Internal Medicine", "int. medicine": "Internal Medicine", "im": "Internal Medicine",
    "general practitioner": "General Practitioner", "gp": "General Practitioner", "gen practitioner": "General Practitioner",
    "nephrologist": "Nephrologist", "nephrology": "Nephrologist",
    "endocrinologist": "Endocrinologist", "endocrinology": "Endocrinologist",
}
raw_spec = h.specialty.copy()
h["specialty"] = h.specialty.str.strip().str.lower().map(spec_map)
assert h.specialty.notna().all(), "unmapped specialty label"
log["hcp_specialty_labels_fixed"] = int((raw_spec != h.specialty).sum())

# 3. region
raw_reg = h.region.copy()
h["region"] = h.region.str.strip().str.title()
log["hcp_region_labels_fixed"] = int((raw_reg != h.region).sum())

# 4. patient volume: sentinel (-1) / impossible values -> NaN, then impute (median by specialty x practice type)
bad = (h.patient_volume <= 0)
q1, q3 = h.patient_volume[~bad].quantile([.25, .75]); iqr = q3 - q1
out = h.patient_volume > q3 + 6 * iqr
log["hcp_patient_volume_sentinel"] = int(bad.sum())
log["hcp_patient_volume_extreme_outliers"] = int(out.sum())
h.loc[bad | out, "patient_volume"] = np.nan
log["hcp_patient_volume_missing_total"] = int(h.patient_volume.isna().sum())
h["volume_imputed"] = h.patient_volume.isna()
h["patient_volume"] = h.groupby(["specialty", "practice_type"]).patient_volume.transform(lambda s: s.fillna(s.median()))

# 5. experience
log["hcp_experience_missing"] = int(h.years_experience.isna().sum())
h["years_experience"] = h.groupby("specialty").years_experience.transform(lambda s: s.fillna(s.median()))

h["kol_flag"] = h.kol_flag.astype(bool); h["email_opt_in"] = h.email_opt_in.astype(bool)
h.to_csv("data/hcp_master_clean.csv", index=False)
log["hcp_rows_clean"] = len(h)

# ------------------------------------------------------------------ Monthly activity
a = pd.read_csv("data/monthly_activity_raw.csv")
log["activity_rows_raw"] = len(a)

# 1. ID normalisation
log["activity_id_case_fixed"] = int((a.hcp_id != a.hcp_id.str.upper().str.strip()).sum())
a["hcp_id"] = a.hcp_id.str.upper().str.strip()

# 2. mixed date formats -> month start
def parse(s):
    for f in ("%Y-%m-%d", "%d/%m/%Y", "%b-%y"):
        try: return pd.to_datetime(s, format=f)
        except ValueError: pass
    return pd.NaT
a["month"] = a.month.map(parse)
log["activity_unparseable_dates"] = int(a.month.isna().sum())

# 3. revenue stored as text with $ and commas
rev_txt = a.revenue_usd.astype(str).str.contains(r"\$")
log["activity_revenue_text_fixed"] = int(rev_txt.sum())
a["revenue_usd"] = pd.to_numeric(a.revenue_usd.astype(str).str.replace(r"[$,]", "", regex=True), errors="coerce")

# 4. duplicates on the natural key
n = len(a); a = a.drop_duplicates(subset=["hcp_id", "month"], keep="first")
log["activity_duplicates_removed"] = n - len(a)

# 5. keying errors in brand_rx: cross-validate against revenue / price
implied = (a.revenue_usd / PRICE).round()
mismatch = (a.brand_rx != implied) & implied.notna()
log["activity_brand_rx_keying_errors"] = int(mismatch.sum())
a.loc[mismatch, "brand_rx"] = implied[mismatch]
a["revenue_usd"] = a.brand_rx * PRICE   # single source of truth

# 6. negative samples (impossible) -> impute from calls (samples ~ 0.8 x calls in historical data)
neg = a.samples < 0
log["activity_negative_samples"] = int(neg.sum())
# 7. missing calls -> HCP's median calls
log["activity_missing_calls"] = int(a.calls.isna().sum())
a["calls_imputed"] = a.calls.isna()
a["calls"] = a.groupby("hcp_id").calls.transform(lambda s: s.fillna(s.median())).round()
a.loc[neg, "samples"] = (0.8 * a.loc[neg, "calls"]).round()

# 8. logical check: brand Rx can never exceed market Rx
log["activity_brand_gt_market_after_fix"] = int((a.brand_rx > a.market_rx).sum())

# 9. completeness (balanced panel?) and orphan IDs
a = a[a.hcp_id.isin(h.hcp_id)]
exp = len(h) * a.month.nunique()
log["activity_panel_expected_rows"] = int(exp); log["activity_rows_clean"] = len(a)
log["activity_missing_hcp_months"] = int(exp - len(a))

for c in ["market_rx", "brand_rx", "calls", "emails", "samples", "events_attended"]:
    a[c] = a[c].astype(int)
a = a.sort_values(["hcp_id", "month"]).reset_index(drop=True)
a.to_csv("data/monthly_activity_clean.csv", index=False)

json.dump(log, open("data/cleaning_log.json", "w"), indent=2)
for k, v in log.items(): print(f"{k:45s} {v}")
